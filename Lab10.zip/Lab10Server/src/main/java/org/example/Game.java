package org.example;

public class Game {
    private String gameId;
    private ClientThread player1;
    private ClientThread player2;
    private boolean isStarted;
    private String currentPlayer;

    public Game(String gameId) {
        this.gameId = gameId;
        this.isStarted = false;
    }

    public String getGameId() {
        return gameId;
    }

    public synchronized boolean addPlayer(ClientThread player) {
        if (player1 == null) {
            player1 = player;
            return true;
        } else if (player2 == null) {
            player2 = player;
            isStarted = true;
            currentPlayer = player1.getClientId();
            return true;
        } else {
            return false;
        }
    }

    public boolean isStarted() {
        return isStarted;
    }

    public synchronized String getCurrentPlayer() {
        return currentPlayer;
    }

    public synchronized ClientThread getOtherPlayer() {
        if (currentPlayer.equals(player1.getClientId())) {
            return player2;
        }
        return player1;
    }

    public synchronized boolean makeMove(String playerId, int row, int col) {
        if (!isStarted) return false;
        if (!playerId.equals(currentPlayer)) return false;

        boolean hit;
        if (playerId.equals(player1.getClientId())) {
            hit = player1.getBoard().makeMove(row, col);
            if (hit) {
                currentPlayer = player1.getClientId(); // Keep current player if hit
            } else {
                currentPlayer = player2.getClientId();
            }
        } else {
            hit = player2.getBoard().makeMove(row, col);
            if (hit) {
                currentPlayer = player2.getClientId(); // Keep current player if hit
            } else {
                currentPlayer = player1.getClientId();
            }
        }

        sendBoardStates();
        checkForWin(getOtherPlayer());
        return hit;
    }

    private void sendBoardStates() {
        player1.sendResponseWithSize(player1.getBoard().getBoardState());
        player2.sendResponseWithSize(player2.getBoard().getBoardState());
    }

    public void checkForWin(ClientThread player) {
        if (!player.getBoard().hasShips()) {
            player1.sendResponseWithSize("YOU " + (player1 == player ? "LOSE" : "WIN"));
            player2.sendResponseWithSize("YOU " + (player2 == player ? "LOSE" : "WIN"));
            isStarted = false; // End the game
        }
    }
}
