package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientThread extends Thread {
    private Socket clientSocket;
    private BufferedReader in;
    private PrintWriter out;
    private GameServer server;
    private String clientId;
    private String gameId;
    private Game game;
    private BattleshipBoard board;

    public ClientThread(Socket clientSocket, GameServer server) {
        this.clientSocket = clientSocket;
        this.server = server;
        this.clientId = clientSocket.getInetAddress().getHostAddress() + ":" + clientSocket.getPort();
        this.board = new BattleshipBoard(game);
        try {
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            out = new PrintWriter(clientSocket.getOutputStream(), true);
        } catch (IOException e) {
            System.err.println("Error creating input/output streams for client socket: " + e.getMessage());
        }
    }

    public String getClientId() {
        return clientId;
    }

    public PrintWriter getOut() {
        return out;
    }

    public BattleshipBoard getBoard() {
        return board;
    }

    @Override
    public void run() {
        server.addClient(clientId, this);
        try {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Received command from client: " + inputLine);
                String[] commandParts = inputLine.split(" ");
                switch (commandParts[0]) {
                    case "stop":
                        server.stop();
                        sendResponseWithSize("Server stopped");
                        break;
                    case "create":
                        gameId = commandParts[1];
                        Game newGame = new Game(gameId);
                        getBoard().setGame(newGame);
                        server.addGame(gameId, newGame);
                        sendResponseWithSize("Game created with ID: " + gameId);
                        break;
                    case "join":
                        gameId = commandParts[1];
                        game = server.getGame(gameId);
                        getBoard().setGame(game);
                        if (game != null && game.addPlayer(this)) {
                            sendResponseWithSize("Joined game: " + gameId);
                        } else {
                            sendResponseWithSize("Failed to join game: " + gameId);
                        }
                        break;
                    case "move":
                        if (commandParts[2].toUpperCase().charAt(0) >= 'A'
                                && commandParts[2].toUpperCase().charAt(0) <= 'H'
                                && commandParts[2].charAt(1) >= '1'
                                && commandParts[2].charAt(1) <= '8') {
                            gameId = commandParts[1];
                            int col = (int) (commandParts[2].toUpperCase().charAt(0) - 'A');
                            int row = Integer.parseInt(commandParts[3]) - 1;
                            game = server.getGame(gameId);
                            if (game != null && game.isStarted()) {
                                boolean hit = game.makeMove(clientId, row, col);
                                sendResponseWithSize("Move result: " + (hit ? "hit" : "miss"));
                            } else {
                                sendResponseWithSize("Invalid game or game not started: " + gameId);
                            }
                        }
                        else
                            sendResponseWithSize("Invalid position! Learn how to read --help");
                        break;
                    case "help":
                        sendResponseWithSize("1.Setting Up the Game Board:\n" +
                                "    The game is played on an 8x8 grid.\n" +
                                "    Rows are numbered from 1 to 8, and columns are labeled with letters from A to H.\n" +
                                "2.Placing the Ships:\n" +
                                "    You need to place the following types of ships:\n" +
                                "        3 ships of size 2\n" +
                                "        2 ships of size 3\n" +
                                "        2 ships of size 4\n" +
                                "        1 ship of size 5\n" +
                                "    Ships can be placed either horizontally (along the X-axis) or vertically (along the Y-axis).\n" +
                                "    The game board is described as follows:\n" +
                                "    “0” represents water (a location where no move has been made).\n" +
                                "    “0-9” represents your own ships.\n" +
                                "    “x” represents a successful hit on an enemy ship.\n" +
                                "3.Gameplay:\n" +
                                "  Each player has two game boards:\n" +
                                "    One shows their own ships.\n" +
                                "    The other shows the opponent’s board, including attacked locations.\n" +
                                "  A valid move is in the format “submit move LN,” where:\n" +
                                "    “L” is an uppercase letter from A to H (column).\n" +
                                "    “N” is a digit from 1 to 8 (row).\n" +
                                "  Example of a valid move: “submit move A5.”\n" +
                                "4.Available Commands for Players:\n" +
                                "  “create game” to create a game.\n" +
                                "  “join game <nickname>” to join a game (where “<nickname>” is your name).\n" +
                                "  “submit move” to make a move.\n" +
                                "  “exit” to leave the game and disconnect from the server.\n" +
                                "  “help” to view the instructions.\n" +
                                "5.Ending the Game:\n" +
                                "  The game ends when you see the message “YOU WIN” or “YOU LOSE.”\n" +
                                "Enjoy the game!");
                    default:
                        sendResponseWithSize("Unknown command: " + commandParts[0]);
                        break;
                }
            }
        } catch (IOException e) {
            System.err.println("Error handling client: " + e.getMessage());
        } finally {
            server.removeClient(clientId);
        }
    }

    public void sendResponseWithSize(String response) {
        String fullResponse = response + "\r\n";
        int messageSize = fullResponse.length();
        out.println(messageSize);
        out.print(fullResponse);
        out.flush();
    }
}
